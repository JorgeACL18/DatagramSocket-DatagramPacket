package Trabajo32;

import java.util.Scanner;
import java.io.IOException;
import java.net.*;

public class ClienteData {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        try {
            InetAddress host = InetAddress.getByName("localhost");
            DatagramSocket socket = new DatagramSocket();

            System.out.println("Conectando servidor...");
            String init = "CONNECT";
            byte[] initBytes = init.getBytes();
            DatagramPacket initPacket = new DatagramPacket(
                initBytes, initBytes.length, host, 9000
            );
            socket.send(initPacket);

            System.out.println("Servidor conectado.");
            System.out.println( "Escribe tu lista (separa las palabras con una coma)");
            String lista = sc.nextLine().trim();
            byte[] buffer = lista.getBytes();
            DatagramPacket paquete = new DatagramPacket(
                buffer, buffer.length, host, 9000
            );
            socket.send(paquete);
            System.out.println("El servidor ha recibido tu mensaje.");

            byte[] respBuffer = new byte[1024];
            DatagramPacket respPaquete = new DatagramPacket(respBuffer, respBuffer.length);

            socket.receive(respPaquete);

            String respuesta = new String(respPaquete.getData(), 0, respPaquete.getLength());
            System.out.println("Respuesta del servidor: " + respuesta);

            socket.close();

            socket.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}


