package Trabajo32;

import java.io.IOException;
import java.net.*;

public class ServidorData {
    public static void main(String[] args) {
        try {
            DatagramSocket socket = new DatagramSocket(9000);
            byte[] buffer = new byte[1024];
            DatagramPacket paquete = new DatagramPacket(buffer, buffer.length);


            System.out.println("Esperando cliente...");
            socket.receive(paquete);
            System.out.println("El cliente se ha conectado. Esperando lista...");

            byte[] buffer2 = new byte[1024];
            DatagramPacket paquete2 = new DatagramPacket(buffer2, buffer2.length);
            socket.receive(paquete2);

            String recibido2 = new String(
                paquete2.getData(), 0, paquete2.getLength()
            );
            System.out.println("Lista recibida del cliente: " + recibido2);

            String[] palabras = recibido2.split(",");
            String mayor = "";
            for (String p : palabras) {
                if (p.length() > mayor.length()) {
                    mayor = p;
                }
            }

            String respuesta = "La palabra más larga es " + mayor +
                                "(longitud: " + mayor.length() + ")";
            System.out.println("Enviando respuesta al cliente...");
            byte[] respBytes = respuesta.getBytes();

            DatagramPacket resp = new DatagramPacket(
                respBytes, respBytes.length, paquete2.getAddress(), paquete2.getPort()
            );

            socket.send(resp);
            System.out.println("Respuesta enviada");

            socket.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}


